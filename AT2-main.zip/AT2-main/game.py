import pygame
from menu import MainMenu
from character_select import CharacterSelect
from map import Map
from level2 import Level2
from level3 import Level3
from level4 import Level4
from losescreen import LoseScreen
from Win_screen import WinScreen
from assets import load_assets, GAME_ASSETS


class Game:
    def __init__(self):
        pygame.init()
        load_assets()  # load the game image assets
        self.window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        self.menu = MainMenu(self.window)  # Create an instance of the MainMenu class
        self.character_select = CharacterSelect(self.window)  # Create an instance of the CharacterSelect class
        self.game_map = Map(self.window)  # Create an instance of the Map class
        self.lose_screen = LoseScreen(self.window)
        self.win_screen = WinScreen(self.window)
        self.state = 'menu'  # Set the initial state to 'menu'
        self.current_character = None  # To store the chosen character

    def run(self):
        while True:
            if self.state == 'menu':  # If the state is 'menu'
                result = self.menu.run()  # Run the menu and get the result
                if result == 'Start Game':  # If the result is 'Start Game'
                    self.state = 'character_select'  # Change the state to 'character_select'
                elif result == 'Settings':  # If the result is 'Settings'
                    pass  # Settings handlingx would go here
                elif result == 'Exit':  # If the result is 'Exit'
                    pygame.quit()  # Quit pygame
                    return  # Exit the run method

            elif self.state == 'character_select':  # If the state is 'character_select'
                selected_character = self.character_select.run()  # Run the character select screen and get the selected character
                if selected_character == 'back':  # If the selected character is 'back'
                    self.state = 'menu'  # Change the state to 'menu'
                elif selected_character:  # If a character is selected
                    self.current_character = selected_character  # Set the current character to the selected character
                    self.game_map.load_player(selected_character)  # Load the selected character into the game map
                    self.health_bar = self.game_map.heath_bar
                    self.state = 'game_map'  # Change the state to 'game_map' 

            elif self.state == 'game_map':  # If the state is 'game_map'
                game_state = self.game_map.gameState()

                if game_state == "Combat":
                    result = self.game_map.inCombat()

                    if result == "lose":
                         self.state = 'lose_screen'
                    
                    if result == "won combat":
                         game_state = "Regular"

                if game_state == "Regular":
        
                    result = self.game_map.handle_events()  # Handle events in the game map and get the result
                    if result == 'back':  # If the result is 'back'
                            self.state = 'character_select'  # Change the state to 'character_select'
                    if result == 'lose':
                            self.state = 'lose_screen'
                    elif result == 'quit':  # If the result is 'quit'
                            pygame.quit()  # Quit pygame
                            return  # Exit the run method

                    elif result ==  "next level":
                         self.level2 = Level2(self.window, self.game_map.getPlayer())
                         self.state = "level2"
                    else:
                        self.game_map.draw()  # Draw the game map
            
            elif self.state == 'level2':  # If the state is 'game_map'
                game_state = self.level2.gameState()

                if game_state == "Combat":
                    result = self.level2.inCombat()

                    if result == "lose":
                         self.state = 'lose_screen'
                    
                    if result == "won combat":
                         game_state = "Regular"

                if game_state == "Regular":
        
                    result = self.level2.handle_events()  # Handle events in the game map and get the result
                    if result == 'back':  # If the result is 'back'
                            self.state = 'character_select'  # Change the state to 'character_select'
                    if result == 'lose':
                            self.state = 'lose_screen'
                    elif result == 'quit':  # If the result is 'quit'
                            pygame.quit()  # Quit pygame
                            return  # Exit the run method

                    elif result ==  "next level":
                         self.level3 = Level3(self.window, self.level2.getPlayer())
                         self.state = "level3"
                    else:
                        self.level2.load_player(self.game_map.player_type)
                        self.level2.draw()  # Draw the game map

            elif self.state == "level3":
                game_state = self.level3.gameState()

                if game_state == "Combat":
                    result = self.level3.inCombat()

                    if result == "lose":
                         self.state = 'lose_screen'
                    
                    if result == "won combat":
                         game_state = "Regular"

                if game_state == "Regular":
        
                    result = self.level3.handle_events()  # Handle events in the game map and get the result
                    if result == 'back':  # If the result is 'back'
                            self.state = 'character_select'  # Change the state to 'character_select'
                    if result == 'lose':
                            self.state = 'lose_screen'
                    elif result == 'quit':  # If the result is 'quit'
                            pygame.quit()  # Quit pygame
                            return  # Exit the run method

                    elif result ==  "next level":
                         self.level4 = Level4(self.window, self.level3.getPlayer())
                         self.state = "level4"
                    else:
                        self.level3.load_player(self.game_map.player_type)
                        self.level3.draw()  # Draw the game map
                
            elif self.state == "level4":
                game_state = self.level4.gameState()

                if game_state == "Combat":
                    result = self.level4.inCombat()

                    if result == "lose":
                         self.state = 'lose_screen'
                    
                    if result == "won combat":
                         game_state = "Regular"

                if game_state == "Regular":
        
                    result = self.level4.handle_events()  # Handle events in the game map and get the result
                    if result == 'back':  # If the result is 'back'
                            self.state = 'character_select'  # Change the state to 'character_select'
                    if result == 'lose':
                            self.state = 'lose_screen'
                    elif result == 'quit':  # If the result is 'quit'
                            pygame.quit()  # Quit pygame
                            return  # Exit the run method

                    elif result ==  'win screen':
                         self.state = "winScreen"
                    else:
                        self.level4.load_player(self.game_map.player_type)
                        self.level4.draw()  # Draw the game map


            elif self.state == 'lose_screen':
                result = self.lose_screen.run()
                if result == 'back':
                    self.state = 'menu'
            
            elif self.state == 'winScreen':
                 result = self.win_screen.run()
                 if result == 'back':
                      self.state = 'menu'

            for event in pygame.event.get():  # Iterate over the events in the event queue
                if event.type == pygame.QUIT:  # If the event type is QUIT
                    pygame.quit()  # Quit pygame
                    return  # Exit the run method

if __name__ == "__main__":
    game = Game()  # Create an instance of the Game class
    game.run()  # Run the game
